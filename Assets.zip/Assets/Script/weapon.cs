﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class weapon : MonoBehaviour
{
        public Transform firepoint;
        public GameObject bullet;

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Fire1"))
		{
            shoot();
		}
    }
    void shoot()
	{
        Instantiate(bullet, transform.position, transform.rotation);
	}
}
